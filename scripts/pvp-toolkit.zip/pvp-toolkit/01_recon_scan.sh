#!/usr/bin/env bash
# ============================================================
# 01_recon_scan.sh — scoped recon for PvP 2026
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./01_recon_scan.sh
#
# Requires: nmap (open-source, installed by default on Kali)
# Only touches hosts listed in scope.env. Run this AFTER the
# 30-minute grace period has ended.
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

echo "=== Sweeping scope for team $TARGET_TEAM ==="

for ip in "${SCOPE_HOSTS[@]}"; do
    assert_in_scope "$ip"
    echo
    echo "---- $ip ----"
    out="$OUTDIR/nmap_${ip//./_}.txt"
    # -Pn: boxes may block ping. -sV: service/version detection.
    # -T4: reasonably fast without being a sledgehammer on a shared range.
    # top 1000 ports is enough for an initial pass; widen with -p- if needed.
    nmap -Pn -sV -T4 --open -oN "$out" "$ip" || true
    cat "$out"
done

echo
echo "=== Quick summary of what's open, per named box ==="
echo " .50 thehouse    (expect: LDAP 389/636 + base Windows AD ports)"
echo " .51 sunflower   (expect: SMB 445/139)"
echo " .52 cherrybomb  (expect: HTTP 80/443, Pi-hole admin on 80/tcp or custom port, DNS 53)"
echo " .53 chomper     (expect: DB port — mysql 3306 / postgres 5432, confirm with nmap output)"
echo " .54 peashooter  (expect: SSH 22)"
echo
echo "Full nmap output saved under: $OUTDIR"
echo "Next: run the matching NN_*.sh script for whichever box(es) you want to pursue."
