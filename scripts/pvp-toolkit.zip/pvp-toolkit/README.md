# PvP 2026 (Purple vs Purple) Attack Toolkit

Built from the briefing packet. Read this whole file before running anything.

## Rules baked into these scripts

- **Scope is hard-coded**: every script sources `scope.env`, which only
  knows about `172.16.XX.50`–`.54` for the opponent team number you set.
  `assert_in_scope` refuses to run against anything else — including
  `.1` (pod routers) and `.2` (kali machines), which the packet says are
  explicitly off-limits.
- **Nothing runs before the grace period ends.** These scripts don't know
  what time it is — that's on you. Don't invoke them for the first 30
  minutes of the comp.
- **Open-source tools only** (nmap, smbclient, ldapsearch, enum4linux-ng,
  netexec/crackmapexec, nikto, gobuster, hydra) — matches "you shouldn't
  pay for anything."
- **Flags are read-only.** `07_flag_grabber.sh` only ever `cat`s/`get`s a
  copy of the flag file — it never deletes, moves, or edits anything on
  the target. Altering a flag or its location is an explicit
  disqualification rule.
- **No auto-submission.** You still run `/submit_flag` yourself in your
  team's Discord channel — scripts just help you find the flag faster.
- **Credential sprays are opt-in and sized small on purpose.** The
  scripts suggest trying the competition's own released default
  credentials first (per the "Default Credentials" section) before any
  brute force, and intentionally don't ship a giant password list —
  pulling in something like rockyou against a shared competition subnet
  is slow, noisy, and likely to just get you flagged by Green Team for
  hammering the network.

## Setup (cloning into the comp environment from GitHub)

```bash
git clone <your-repo-url> pvp-toolkit
cd pvp-toolkit
./setup.sh              # chmod +x's everything, installs missing tools
export TARGET_TEAM=07   # the opponent team's number, from their IP/discord channel
./01_recon_scan.sh
```

### Before comp day — test the clone path on a network you control
`setup.sh` installs tools via `apt`, which needs internet access **from the
Kali machine itself**, not just from your laptop. Competition pod networks
are sometimes locked down to just the pod subnet. Do a dry run beforehand:
get onto a Kali box on a similar network and confirm `git clone` and `apt
install` both actually work from there. If they don't, `apt download` the
`.deb` packages ahead of time and bring them in some other way (the comp
instructions should say what's allowed for bringing in your own files), or
pre-install everything into a Kali snapshot before the event.

### What NOT to commit to the repo
- `loot/` — this fills up with scan output, scraped usernames, and flag
  contents over the course of the comp. It's already in `.gitignore`.
- `wordlists/*.txt` — the comp's own released default credentials and any
  password list you build from them shouldn't end up in your git history,
  especially if the repo is public. Also gitignored.
- Nothing in this toolkit currently hardcodes `TARGET_TEAM` or real
  credentials — those only ever exist as environment variables or local
  files under `loot/`/`wordlists/`, so a plain `git clone` of the repo as-is
  is safe to make public before/after the comp.

Then run whichever per-box script matches what you want to go after:

| Script                     | Box         | OS                | Scored service |
|----------------------------|-------------|-------------------|----------------|
| `02_ldap_thehouse.sh`      | thehouse    | Windows Server 2022 | LDAP          |
| `03_smb_sunflower.sh`      | sunflower   | Windows Server 2019 | SMB           |
| `04_web_cherrybomb.sh`     | cherrybomb  | Ubuntu 25.04        | Pi-hole/HTTP  |
| `05_db_chomper.sh`         | chomper     | CentOS 10           | Database      |
| `06_ssh_peashooter.sh`     | peashooter  | Debian 12           | SSH           |

Once you have working credentials or a shell/share on any box:

```bash
./07_flag_grabber.sh ssh 172.16.07.54 tanglekelp
./07_flag_grabber.sh smb 172.16.07.51 Administrator 'NewP@ssw0rd'
```

## Tools you'll want installed (all free/open-source, standard on Kali)

```
nmap ldap-utils smbclient enum4linux-ng nikto gobuster hydra netexec mysql-client postgresql-client
```

On Kali: `sudo apt update && sudo apt install -y ldap-utils enum4linux-ng nikto gobuster hydra netexec`

## A note on strategy

Given the scoring model (uptime points for *your own* services, flag
points off *opponents*), it's usually worth running `01_recon_scan.sh`
against yourself first (swap `TARGET_TEAM` for your own number) so you
know exactly what you're exposing, patch/harden it, *then* go hunt
opponents. The packet's grace period exists for exactly this.
