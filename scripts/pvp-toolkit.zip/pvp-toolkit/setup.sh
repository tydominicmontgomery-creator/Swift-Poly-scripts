#!/usr/bin/env bash
# ============================================================
# setup.sh — run once, right after `git clone`, on the comp Kali box
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

echo "[*] Making scripts executable (git doesn't always preserve +x on clone)..."
chmod +x *.sh

echo "[*] Checking for required tools..."
need=(nmap smbclient ldapsearch enum4linux-ng nikto gobuster hydra netexec)
missing=()
for t in "${need[@]}"; do
    command -v "$t" >/dev/null 2>&1 || missing+=("$t")
done

if [[ "${#missing[@]}" -gt 0 ]]; then
    echo "[!] Missing: ${missing[*]}"
    echo "[*] Installing (requires sudo + internet access FROM the Kali box)..."
    sudo apt update
    sudo apt install -y ldap-utils enum4linux-ng nikto gobuster hydra netexec smbclient nmap
else
    echo "[*] All required tools already present."
fi

mkdir -p wordlists loot
echo
echo "[*] Setup done. Next steps:"
echo "    1. export TARGET_TEAM=<opponent's team number>"
echo "    2. ./01_recon_scan.sh"
echo
echo "[!] Reminder: don't run anything attack-related until the 30-minute"
echo "    grace period has ended."
