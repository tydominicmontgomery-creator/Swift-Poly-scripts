#!/usr/bin/env bash
# ============================================================
# 07_flag_grabber.sh — read (NEVER modify) flags once you have
# working credentials/access to a box in scope.
# ============================================================
# Packet rule: "DO NOT CHANGE/ALTER THE FLAGS OR THEIR LOCATIONS.
# IF YOU DO, YOU WILL BE DISQUALIFIED." This script only ever reads.
#
# Known flag locations from the packet:
#   Linux:   /root/flag.txt   /user/flag.txt  (note: may be secret ones elsewhere)
#   Windows: C:\Windows\flag.txt
#
# After reading a flag, submit it yourself via /submit_flag in your
# team's Discord channel — this script does NOT auto-submit anything.
#
# Usage:
#   ./07_flag_grabber.sh ssh <ip> <username> [identity_file]
#   ./07_flag_grabber.sh smb <ip> <username> <password>
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

MODE="${1:-}"
IP="${2:-}"
[[ -z "$MODE" || -z "$IP" ]] && { echo "Usage: $0 <ssh|smb> <ip> ..."; exit 1; }
assert_in_scope "$IP"

OUT="$OUTDIR/flags"
mkdir -p "$OUT"
STAMP="$(date +%Y%m%d_%H%M%S)"

case "$MODE" in
  ssh)
    USERNAME="${3:?Need username}"
    IDENTITY="${4:-}"
    SSH_OPTS=(-o StrictHostKeyChecking=no -o ConnectTimeout=6)
    [[ -n "$IDENTITY" ]] && SSH_OPTS+=(-i "$IDENTITY")

    echo "[*] Read-only check of known flag paths over SSH as $USERNAME@$IP ..."
    # Exact paths: safe to quote on both ends.
    for path in /root/flag.txt /user/flag.txt; do
        echo "--- $path ---"
        ssh "${SSH_OPTS[@]}" "$USERNAME@$IP" "cat '$path' 2>/dev/null" \
            | tee -a "$OUT/${IP}_${STAMP}.txt" || true
    done
    # Glob path: must stay UNQUOTED when it reaches the remote shell so the
    # expansion happens there (on the target), not locally on your attack box
    # and not frozen-as-literal by premature quoting.
    HOME_GLOB='/home/*/flag.txt'
    echo "--- $HOME_GLOB (expanded remotely) ---"
    ssh "${SSH_OPTS[@]}" "$USERNAME@$IP" "cat $HOME_GLOB 2>/dev/null" \
        | tee -a "$OUT/${IP}_${STAMP}.txt" || true

    echo "[*] Also doing a broad (read-only) find in case of a 'secret' flag:"
    ssh "${SSH_OPTS[@]}" "$USERNAME@$IP" \
        "find / -xdev -iname 'flag*.txt' -readable 2>/dev/null" \
        | tee -a "$OUT/${IP}_${STAMP}_find.txt" || true
    ;;

  smb)
    USERNAME="${3:?Need username}"
    PASSWORD="${4:?Need password}"

    echo "[*] Read-only pull of C:\\Windows\\flag.txt via SMB as $USERNAME@$IP ..."
    smbclient "//$IP/C\$" -U "$USERNAME%$PASSWORD" \
        -c "lcd $OUT; get Windows\\flag.txt ${IP}_${STAMP}_flag.txt" || true
    if [[ -f "$OUT/${IP}_${STAMP}_flag.txt" ]]; then
        echo "--- flag.txt ---"
        cat "$OUT/${IP}_${STAMP}_flag.txt"
    fi
    ;;

  *)
    echo "Unknown mode: $MODE (use ssh or smb)"; exit 1 ;;
esac

echo
echo "[*] Reminder: submit any found SHA-256 flag yourself with /submit_flag"
echo "    in YOUR team's Discord channel. This script never auto-submits,"
echo "    never writes/deletes/moves the flag file, and never touches"
echo "    anything outside the paths above."
